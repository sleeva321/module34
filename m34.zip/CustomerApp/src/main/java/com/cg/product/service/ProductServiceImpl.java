package com.cg.product.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.product.bean.Product;
import com.cg.product.dao.IProductDao;

@Service
public class ProductServiceImpl implements IProductService {
	@Autowired
	IProductDao productdao;

	@Override
	public List<Product> viewAllProduct() {
		
		return productdao.findAll();
	}

	@Override
	public Product updateProduct(Product obj, String id) {
		
		Optional<Product> obj1 =productdao.findById(id);
		if(obj1.isPresent())
		{
			
			double d=(obj.getPrice()*obj.getDiscount())/100;
			double price=obj.getPrice()-d;
			obj.setDiscounted(price);
			
		
			
			productdao.save(obj);
			return obj;
		}
		return null;
		
		
	}

	@Override
	public Product findSingleProduct(String id) {
		
		return productdao.findById(id).get();
	}

	
}
